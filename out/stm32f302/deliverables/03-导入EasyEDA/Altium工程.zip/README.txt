main — Altium Designer project

Generated in Altium's native binary document format from the board's routed Circuit JSON.
Open main.PrjPcb in Altium Designer.